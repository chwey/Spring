package com.yedam.persistence;

import com.yedam.domain.BookVO;

public interface BookMapper {
	public void insertSelectKey (BookVO book);
}
