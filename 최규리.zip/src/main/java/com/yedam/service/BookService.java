package com.yedam.service;

import com.yedam.domain.BookVO;

public interface BookService {
	public void register(BookVO book);
}
